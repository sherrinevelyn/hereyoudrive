<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>hereyourdrive</title>

        <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
    </head>
    <body>

        <section class="hero">
            <header>
                <div class="logo">
                    <img id="header-img" class="logo" src="<?php echo e(asset('assets/photos/driving-school.png')); ?>">
                    <h1>hereyoudrive</h1>
                </div>
    
                <ul class="navigation">
                    <li>
                        <a class="nav-link" href="#Home">Home</a>
                    </li>
                    <li>
                        <a class="nav-link" href="#ClassSchedule">Schedule</a>
                    </li>
                    <li>
                        <a class="out-people" href="#OurPeople">Our People</a>
                    </li>
                    <li>
                        <a class="nav-link" href="#About-us">About Us</a>
                    </li> 
                </ul>
            </header>

            <div class="caption">
                <p> 
                    <b>hereyoudrive</b> is a certified driving class that many class choices and can make your own schedule. hereyoudrive is established on 2022.The idea of hereyoudrive is to learn driving whenever you can. when you have a freetime and want to drive just come tp our place. Our people will teach you how to drive.
                </p>
            </div>
        </section>

        <section class="schedule">
            <h1>Available Class</h1>

            <table>
                <thead>
                    <tr>
                        <th colspan="2">Everyday</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>09.00 - 10.00</td>
                        <td>15.00 - 16.00</td>
                    </tr>
                    <tr>
                        <td>10.00 - 11.00</td>
                        <td>16.00 - 17.00</td>
                    </tr>
                    <tr>
                        <td>11.00 - 12.00</td>
                        <td>17.00 - 18.00</td>
                    </tr>
                    <tr>
                        <td>12.00 - 13.00</td>
                        <td>18.00 - 19.00</td>
                    </tr>
                    <tr>
                        <td>13.00 - 14.00</td>
                        <td>19.00 - 20.00</td>
                    </tr>
                    <tr>
                        <td>14.00 - 15.00</td>
                        <td>20.00 - 21.00</td>
                    </tr>
                </tbody>
            </table>
        </section>

        <section class="people">
            <h1>Our People</h1>
            
            <h2 class="people-trainer">Trainer</h2>
            <div class="people-list">
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Jay</h1>
                </div>
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Jonathan</h1>
                </div>
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Jake</h1>
                </div>
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Jonathan</h1>
                </div>
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Jake</h1>
                </div>
            </div>

            
            <h2 class="people-manager">Manager</h2>
            <div class="people-list">
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Joshua</h1>
                </div>
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Harry</h1>
                </div>
                <div class="people-item">
                    <img src="<?php echo e(asset('assets/photos/user.png')); ?>">
                    <h1>Christian</h1>
                </div>
            </div>
        </section>

        <section class="about">
            <h1>About Us</h1>

            <div class="about-location">
                <h2>Our Location</h2>
                <p>Winkleroad 1st, Jakarta, Indonesia.</p>
            </div>

            <div class="about-socmed">
                <h2>Social Media</h2>
                
                <img  src="<?php echo e(asset('assets/photos/instagram.png')); ?>" width="70">
                <img src="<?php echo e(asset('assets/photos/whatsapp.png')); ?>" width="70">
            </div>
        </section>
    </body>
</html>